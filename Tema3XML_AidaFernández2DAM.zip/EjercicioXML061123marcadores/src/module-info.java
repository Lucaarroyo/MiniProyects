/**
 * 
 */
/**
 * 
 */
module EjercicioXML061123marcadores {
	requires java.xml;
}