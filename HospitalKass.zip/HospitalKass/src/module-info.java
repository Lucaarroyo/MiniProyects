/**
 * 
 */
/**
 * 
 */
module HospitalKass {
}